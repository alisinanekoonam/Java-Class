package Classes.Restaurant;

class Customer {
    private static int nextCustomerId = 1;
    private int customerNumber;
    private String name;
    private Address address;

    public Customer(String name, Address address) {
        this.customerNumber = nextCustomerId++;
        this.name = name;
        this.address = address;
    }

    public int getCustomerNumber() {
        return customerNumber;
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return address;
    }

    // No setters as requested (customer number is unique)
}