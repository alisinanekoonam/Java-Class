package Classes.Restaurant;

class Food {
    private static Food[] menu = new Food[0]; // Initially empty menu

    private String name; // Not static
    private int price;

    public Food(String name, int price) {
        this.name = name;
        this.price = price;
        // Add this food to the menu
        Food[] newMenu = new Food[menu.length + 1];
        System.arraycopy(menu, 0, newMenu, 0, menu.length);
        newMenu[newMenu.length - 1] = this;
        menu = newMenu;
    }

    public static Food[] getMenu() {
        return menu;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Getter for price
    public int getPrice() {
        return price;
    }
}

