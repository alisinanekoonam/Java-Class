package Classes.Restaurant;

class Address {
    private double latitude;
    private double longitude;
    private String written_address;

    public Address(double latitude, double longitude, String written_address) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.written_address = written_address;
    }

    public double distanceFrom(Address other) {
        double lat1 = this.latitude;
        double lat2 = other.latitude;
        double lon1 = this.longitude;
        double lon2 = other.longitude;

        double dlon = lon2 - lon1;
        double dlat = lat2 - lat1;

        double a = Math.pow(dlon, 2) + Math.pow(dlat, 2);

        double c = Math.sqrt(a);

        return c;
    }

    // Getters (no setters as requested)
    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getWrittenAddress() {
        return written_address;
    }
}