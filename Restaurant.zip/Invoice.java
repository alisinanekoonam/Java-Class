package Classes.Restaurant;

class Invoice {
    public final static float TAX_RATE = 0.094f; // Unchangeable tax rate

    private int state = -1; // -1: registering, 0: preparing, 1: delivering, 2: delivered
    private Customer customer;
    private Item[] items = new Item[0];

    public Invoice(Customer customer) {
        this.customer = customer;
    }

    public boolean addItem(Item item) {
        if (state == -1) { // Only allow adding items while registering
            Item[] newItems = new Item[items.length + 1];
            System.arraycopy(items, 0, newItems, 0, items.length);
            newItems[newItems.length - 1] = item;
            items = newItems;
            return true;
        } else {
            return false;
        }
    }

    public boolean removeItem(Item item) {
        if (state == -1) { // Only allow removing items while registering
            int index = findItemIndex(item);
            if (index != -1) {
                Item[] newItems = new Item[items.length - 1];
                System.arraycopy(items, 0, newItems, 0, index);
                System.arraycopy(items, index + 1, newItems, index, items.length - index - 1);
                items = newItems;
                return true;
            }
        }
        return false;
    }

    private int findItemIndex(Item item) {
        for (int i = 0; i < items.length; i++) {
            if (items[i].getFood() == item.getFood()) {
                return i;
            }
        }
        return -1;
    }

    public void nextStage() {
        if (state < 2) {
            state++;
        }
    }

    public int getState() {
        return state;
    }

    public Item[] getItems() {
        return items;
    }

    public int getTotalPrice() {
        int totalPrice = 0;
        for (Item item : items) {
            totalPrice += item.getCount() * item.getFood().getPrice();
        }
        return Math.round(totalPrice * (1 + TAX_RATE));
    }

    public Customer getCustomer() {
        return customer;
    }
}
